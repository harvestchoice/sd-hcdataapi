﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Linq.Dynamic;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using HarvestChoiceApi.Models;
using System.Web.Http.OData.Query;
using HarvestChoiceApi.Documentation.Models;
using System.Linq.Expressions;
using System.Collections;
using LinqKit;
using System.Data.SqlClient;

namespace HarvestChoiceApi.Controllers
{
    public class CellValuesController : ApiController
    {
        private HC_WEB_DB_Connection db = new HC_WEB_DB_Connection();

        // GET api/CellValues
        /// <summary>
        /// Gets Cell Values
        /// </summary>
        /// <returns></returns>
        //[Queryable(AllowedQueryOptions = AllowedQueryOptions.All, PageSize=10)]
        //[ApiReturnType(typeof(CELL_VALUES))]
        //public IEnumerable<CELL_VALUES> GetCELL_VALUES()
        //{
        //    return db.CELL_VALUES.AsEnumerable();
        //}

        // GET api/CellValues/5
        /// <summary>
        /// Gets all data for a specific cell value.
        /// </summary>
        /// <param name="id">CELL5M Id.</param>
        /// <example>http://208.109.190.171/HarvestChoiceApi/0.1/api/cellvalues/3267978</example>
        /// <returns>All data for a specific cell value.</returns>
        [ApiReturnType(typeof(CELL_VALUES))]
        public CELL_VALUES GetCELL_VALUES(int id)
        {
            CELL_VALUES cell_values = db.CELL_VALUES.Find(id);
            if (cell_values == null)
            {
                throw new HttpResponseException(Request.CreateResponse(HttpStatusCode.NotFound));
            }

            return cell_values;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="indicators"></param>
        /// <param name="domains"></param>
        /// <param name="countries"></param>
        /// <example>/api/cellvalues?indicatorIds=266&indicatorIds=197&indicatorIds=78&indicatorIds=139&domainIds=8</example>
        /// <returns></returns>       
        [ApiReturnType(typeof(CellValues))]
        public CellValues GetCellValues([FromUri]int[] indicatorIds, [FromUri]int[] domainIds = null, [FromUri]string[] countryIds = null)
        {

            CellValues cellvalues = new CellValues();//returned object

            List<Indicator> indicators = new List<Indicator>();//list of valid indicators
            List<Domains> domains = new List<Domains>();//list of valid domains

            string selectstatement = "SELECT DISTINCT ISO3 FROM DBO.CELL_VALUES";
            SqlConnection conn = 
                new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["HC_WEB_DB"].ConnectionString);
            conn.Open();
            SqlCommand cmd = new SqlCommand(selectstatement, conn);
            SqlDataReader dataReader = cmd.ExecuteReader();
            while (dataReader.Read())
            {
                string data = dataReader[0].ToString();
            }

            string select = "new(";         //dynamic linq select
            string where = string.Empty;    //dynamic linq where
            string groupby = string.Empty;  //dynamic linq groupby
            List<string> indicatorColumns = new List<string>();
            //List<string> valueList = new List<string>();



            #region Get Indicators
            if (indicatorIds != null && indicatorIds.Length != 0)
            {
                //get indicators
                foreach (int indicatorId in indicatorIds)
                {
                    //Get the indicator by Id from allowed indicators
                    indicator_metadata indicator_metadata = db.indicator_metadata.SingleOrDefault(x =>
                        x.id == indicatorId
                        && (x.published == true || x.published == null));

                    //Invalid indicator requests are ignored
                    if (indicator_metadata != null)
                    {
                        Indicator indicator = new Indicator();
                        indicator.Id = indicator_metadata.id;
                        indicator.ColumnName = indicator_metadata.column_name;
                        indicator.MicroLabel = indicator_metadata.micro_label;
                        indicator.Unit = indicator_metadata.unit;
                        indicator.Year = indicator_metadata.year;
                        indicator.DecimalPlaces = indicator_metadata.decimal_places;
                        indicator.ClassificationType = indicator_metadata.classification_type;
                        indicator.AggType = indicator_metadata.agg_type;
                        indicator.AggFormula = indicator_metadata.agg_formula;

                        indicators.Add(indicator);
                    }
                }
            }
            #endregion

            #region Get Domains
            if (domainIds != null && domainIds.Length != 0)
            {
                //get domains
                foreach (int domainId in domainIds)
                {
                    //get the domain from the allowed domains
                    schema schema = db.schemata.SingleOrDefault(x =>
                        x.id == domainId
                        && (x.published == true || x.published == null)
                        && (x.for_mappr == true || x.for_mappr == null));

                    //invalid domains are ignored
                    if (schema != null)
                    {
                        Domains domain = new Domains();
                        domain.Id = schema.id;
                        domain.Description = schema.description;
                        domain.Name = schema.name;
                        domain.DomainAreas = schema.schema_domain.AsEnumerable()
                            .Select(x => new DomainArea
                            {
                                Id = x.id,
                                ColumnName = x.domain_variable.column_name,
                                MicroLabel = x.domain_variable.micro_label,
                                LongDescription = x.domain_variable.long_description,
                                Unit = x.domain_variable.unit,
                                Year = x.domain_variable.year,
                                DecimalPlaces = x.domain_variable.decimal_places,
                                ClassificationType = x.domain_variable.classification_type,
                                AggType = x.domain_variable.agg_type,
                                AggFormula = x.domain_variable.agg_formula,
                                Classifications = x.domain_variable.classification_type.ToUpper() == "CONTINUOUS" ?
                                x.domain_variable.continuous_classification.AsEnumerable()
                                    .Select(cc => new Classification
                                    {
                                        Name = cc.classification.name,
                                        Max = cc.max,
                                        Min = cc.min,
                                        SortOrder = cc.sortorder
                                    }).ToList() :
                                x.domain_variable.discrete_classification.AsEnumerable()
                                    .Select(dc => new Classification
                                    {
                                        Name = dc.classification.name,
                                        Value = dc.originalid,
                                        SortOrder = dc.sortorder
                                    }).ToList()
                            }).ToList();

                        domains.Add(domain);
                    }
                }
            }
            #endregion

            //Must have at least 1 indicator
            if (indicators.Count > 0)
            {
                //remove all indicators that are not of type continuous
                indicators.RemoveAll(x => x.ClassificationType.ToUpper() != "CONTINUOUS");

                //Process each indicator and prepare the Select statement
                foreach (Indicator indicator in indicators)
                {
                    indicatorColumns.Add(indicator.ColumnName);
                    //IF THERE ARE ONLY INDICATORS THEN THE TABLE WILL BE ONLY ONE ROW OF ITEMS                                                            
                    switch (indicator.AggType.ToUpper())
                    {
                        case "AVG":
                            select += "Average(" + indicator.ColumnName + ") as " + indicator.ColumnName;
                            //var average = db.CELL_VALUES.Average(indicator.ColumnName);
                            //valueList.Add(average.ToString());
                            break;
                        case "SUM":
                            select += "Sum(" + indicator.ColumnName + ") as " + indicator.ColumnName;
                            //var sumation = db.CELL_VALUES.Sum(indicator.ColumnName);
                            //valueList.Add(sumation.ToString());
                            break;
                        case "WGHTD":
                            string aggFormula = indicator.AggFormula.Replace("SUM", "Sum");
                            select += aggFormula + " as " + indicator.ColumnName;
                            break;
                        default:
                            //unknown aggregate type
                            break;
                    }
                    //need to add a comma if not at the last indicator
                    if (indicators.Last() != indicator) select += ",";
                    //need to add a comma if there are domains to add to the select list
                    //else if (domains.Count > 0) select += ",";
                    //close the select statement if there are no domains
                    else select += ")";
                }

                //process domain select,where & groupby statements
                if (domains.Count > 0)
                {
                    foreach (Domains domain in domains)
                    {
                        foreach (DomainArea domainArea in domain.DomainAreas)
                        {
                            if (domainArea.ClassificationType.ToUpper() == "CONTINUOUS")
                            {
                               // select += domainArea.ColumnName;
                                foreach (Classification classification in domainArea.Classifications)
                                {
                                    groupby += "(" + domainArea.ColumnName + " > " + classification.Min + " AND ";
                                    groupby += domainArea.ColumnName + " <= " + classification.Max + ") as " + classification.Name;
                                    if (domainArea.Classifications.Last() != classification) groupby += ",";
                                }
                            }
                            else if (domainArea.ClassificationType.ToUpper() == "CLASS")
                            {
                                //select += domainArea.ColumnName;
                                foreach (Classification classification in domainArea.Classifications)
                                {
                                    groupby += "(" + domainArea.ColumnName + " = " + classification.Value + ") as " + classification.Name;
                                    if (domainArea.Classifications.Last() != classification) groupby += ",";
                                }
                            }
                            ////need to add a comma if not at the last domainArea
                            //if (domain.DomainAreas.Last() != domainArea) select += ",";
                            ////close the select statement if there are no domains
                            //else select += ")";
                        }
                    }
                }
                double[] aezRange = { 311, 315, 321, 322, 323, 324 };

                //var group = CELL_VALUES.ContainsCountries("BDI", "KEN");
                var aez = CELL_VALUES.ContainsAEZ(aezRange);

                //var cells = db.CELL_VALUES.AsExpandable()
                //    .Where(aez)
                //    .Select("new(TPOV_PT125, COTT_R_Y, COTT_R, COTT_I_H, AEZ_CODE, ISO3)");



                var results = db.CELL_VALUES.AsExpandable()
                    .Where(aez)
                    .GroupBy(x => x.AEZ_CODE)
                    .Select(@select);

                var result = db.udf_ExecuteSQLStatemnt("SELECT DISTINCT ISO3 FROM DBO.CELL_VALUES");                             


                //var result = db.CELL_VALUES.AsQueryable()
                //.GroupBy(uselessConst => 0)
                //.Select(@select);

                //.Select(@select).Cast<object>().ToList();                            
                //.Select(@"new(Sum(COTT_I_H) as TestAgg)");

                int index = 0;//Keep track of position in results
                //Loop through each row in the results and assign it to the CellValues class
                foreach (var CurrentRow in results)//Loop on row
                {
                    //Look at each field of each row
                    foreach (var FieldPropertyInfo in CurrentRow.GetType().GetProperties())//Loop on field
                    {
                        try
                        {
                            //Use System.Reflection to extract information about our results
                            System.Reflection.MethodInfo GetMethod = FieldPropertyInfo.GetGetMethod();
                            Object Value = GetMethod.Invoke(CurrentRow, null);

                            Columns columnInfo = new Columns();
                            columnInfo.ColumnName = FieldPropertyInfo.Name; //assign the columns name (ie COTT_R, PN05_TOT)

                            //Get the column value's type
                            var type = Nullable.GetUnderlyingType(FieldPropertyInfo.PropertyType) ??
                                FieldPropertyInfo.PropertyType;

                            columnInfo.ValueType = type.Name; //assign the name type (ie. Double, String, Integer)
                            columnInfo.ColumnIndex = index; //assign the column's index

                            cellvalues.ColumnList.Add(columnInfo); //add the column information to the cellvalues class
                            cellvalues.ValueList.Add(Value.ToString());//add the values to the cellvalues class

                            index++; //increment the index
                        }
                        catch (Exception e) { }
                    }
                }

            }

            return cellvalues;
        }
        
    }
}